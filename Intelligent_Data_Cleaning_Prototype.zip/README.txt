# Intelligent Data Cleaning and Error Detection System — Prototype

## Requirements
- Python 3.9 or newer
- Internet connection for installing packages (not needed after installation)

## Run in VS Code
1. Extract this ZIP file.
2. Open the extracted folder in VS Code.
3. Open Terminal → New Terminal.
4. Run:
   `python -m venv venv`
5. Activate the environment:

   Windows PowerShell:
   `venv\\Scripts\\Activate.ps1`

   Windows Command Prompt:
   `venv\\Scripts\\activate.bat`

6. Install packages:
   `pip install -r requirements.txt`
7. Start the app:
   `streamlit run app.py`
8. A browser tab should open. If not, copy the Local URL shown in the terminal (usually http://localhost:8501).

## What to demonstrate
- Start with the built-in sample dataset.
- Show missing values, duplicate rows, extra spaces, invalid email formats and unusual ages.
- Select cleaning operations.
- Compare before and after data.
- Download the cleaned CSV or Excel file.
- Then upload your own CSV/XLSX to demonstrate that it works with other datasets.

## Prototype scope and limitations
- Missing numeric values are filled using the column median; missing text values become "Not Provided".
- Fully identical rows are removed when selected.
- Leading/trailing spaces are removed from text columns.
- Columns containing "city" in the name are standardized to title case.
- Invalid email formats and ages outside 0–120 are flagged for review; the app does not guess corrections.
- This is a prototype, not a production-grade data quality platform.
