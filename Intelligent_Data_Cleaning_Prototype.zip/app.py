import streamlit as st
import pandas as pd
import numpy as np
import re
from io import BytesIO

st.set_page_config(page_title="Intelligent Data Cleaning", page_icon="🧹", layout="wide")
st.title("🧹 Intelligent Data Cleaning and Error Detection System")
st.caption("Prototype | Upload → Detect → Review → Clean → Download")

st.info("This prototype demonstrates rule-based data-quality checks. Review flagged records before applying corrections.")

def read_file(uploaded):
    name = uploaded.name.lower()
    if name.endswith(".csv"):
        return pd.read_csv(uploaded)
    return pd.read_excel(uploaded)

def email_valid(value):
    if pd.isna(value) or str(value).strip() == "":
        return True
    return bool(re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", str(value).strip()))

def analyze(df):
    issues = {}
    issues["Missing cells"] = int(df.isna().sum().sum())
    issues["Duplicate rows"] = int(df.duplicated().sum())
    issues["Text values with extra spaces"] = 0
    issues["Email format issues"] = 0
    issues["Potential invalid ages"] = 0

    for col in df.select_dtypes(include=["object"]).columns:
        issues["Text values with extra spaces"] += int(
            df[col].dropna().astype(str).map(lambda x: x != x.strip()).sum()
        )
    email_cols = [c for c in df.columns if "email" in c.lower()]
    for col in email_cols:
        issues["Email format issues"] += int((~df[col].map(email_valid)).sum())
    age_cols = [c for c in df.columns if "age" in c.lower()]
    for col in age_cols:
        numeric = pd.to_numeric(df[col], errors="coerce")
        issues["Potential invalid ages"] += int(((numeric < 0) | (numeric > 120)).sum())
    return issues

def clean_data(df, fill_missing, remove_duplicates, trim_text, standardize_text):
    out = df.copy()
    if trim_text:
        for col in out.select_dtypes(include=["object"]).columns:
            out[col] = out[col].map(lambda x: x.strip() if isinstance(x, str) else x)
    if standardize_text:
        for col in out.select_dtypes(include=["object"]).columns:
            if "city" in col.lower():
                out[col] = out[col].map(lambda x: x.title() if isinstance(x, str) else x)
    if fill_missing:
        for col in out.columns:
            if pd.api.types.is_numeric_dtype(out[col]):
                if out[col].isna().any():
                    out[col] = out[col].fillna(out[col].median())
            elif out[col].isna().any():
                out[col] = out[col].fillna("Not Provided")
    if remove_duplicates:
        out = out.drop_duplicates()
    return out

sample = pd.DataFrame({
    "Student_ID":[101,102,103,104,105,106,107,108,109,110,111,112],
    "Name":["Priya","Arun","Meena","Rahul","Kavin","Divya","Priya","Sanjay","Nila","Vijay","Asha","Ravi"],
    "Age":[21, None, 22, 20, 200, 23, 21, 24, 22, None, 20, 25],
    "Email":["priya@gmail.com","arun@gmail.com","meena@gmail.com","rahulgmail.com","kavin@gmail.com","divya@gmail.com","priya@gmail.com","sanjay@gmail.com","nila@gmail.com","vijay@gmail.com","asha@gmail.com","ravi@gmail.com"],
    "City":["Chennai","Madurai","chennai","Coimbatore"," Madurai ","Trichy","Chennai","MADURAI","Salem","Trichy","salem","Coimbatore"]
})

with st.sidebar:
    st.header("How to use")
    st.write("1. Upload CSV/XLSX or use sample data.")
    st.write("2. Review detected issues.")
    st.write("3. Select cleaning actions.")
    st.write("4. Download cleaned data.")
    use_sample = st.checkbox("Use built-in sample dataset", value=True)
    uploaded = st.file_uploader("Upload CSV or Excel", type=["csv","xlsx"])

if uploaded is not None:
    try:
        original = read_file(uploaded)
    except Exception as e:
        st.error(f"Could not read file: {e}")
        st.stop()
elif use_sample:
    original = sample.copy()
else:
    st.warning("Upload a CSV/Excel file or select the sample dataset in the sidebar.")
    st.stop()

if original.empty:
    st.warning("The uploaded dataset is empty.")
    st.stop()

st.subheader("1. Dataset overview")
c1,c2,c3 = st.columns(3)
c1.metric("Rows", f"{len(original):,}")
c2.metric("Columns", f"{len(original.columns):,}")
c3.metric("Duplicate rows", f"{int(original.duplicated().sum()):,}")
st.dataframe(original.head(100), use_container_width=True)

st.subheader("2. Automatic error detection")
report = analyze(original)
cols = st.columns(5)
for (label,value),col in zip(report.items(), cols):
    col.metric(label, f"{value:,}")
with st.expander("View missing values by column"):
    missing = original.isna().sum().rename("Missing values").to_frame()
    st.dataframe(missing, use_container_width=True)

email_cols = [c for c in original.columns if "email" in c.lower()]
if email_cols:
    with st.expander("View rows with invalid email formats"):
        for col in email_cols:
            bad = original[~original[col].map(email_valid)]
            st.write(f"Column: {col}")
            st.dataframe(bad, use_container_width=True)
age_cols = [c for c in original.columns if "age" in c.lower()]
if age_cols:
    with st.expander("View potentially invalid age values (outside 0–120)"):
        for col in age_cols:
            num = pd.to_numeric(original[col], errors="coerce")
            bad = original[(num < 0) | (num > 120)]
            st.dataframe(bad, use_container_width=True)

st.subheader("3. Choose cleaning operations")
st.caption("These are optional actions. Invalid emails and unusual ages are flagged for manual review, not guessed or automatically changed.")
a,b,c,d = st.columns(4)
fill_missing = a.checkbox("Handle missing values", value=True)
remove_duplicates = b.checkbox("Remove duplicate rows", value=True)
trim_text = c.checkbox("Remove extra spaces", value=True)
standardize_text = d.checkbox("Standardize city names", value=True)

cleaned = clean_data(original, fill_missing, remove_duplicates, trim_text, standardize_text)
st.subheader("4. Before and after comparison")
before, after = st.columns(2)
before.metric("Rows before cleaning", len(original))
after.metric("Rows after cleaning", len(cleaned))
before.dataframe(original.head(8), use_container_width=True)
after.dataframe(cleaned.head(8), use_container_width=True)

st.subheader("5. Download cleaned dataset")
csv_bytes = cleaned.to_csv(index=False).encode("utf-8-sig")
st.download_button("⬇️ Download cleaned CSV", data=csv_bytes, file_name="cleaned_dataset.csv", mime="text/csv")
excel_buffer = BytesIO()
with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
    cleaned.to_excel(writer, index=False, sheet_name="Cleaned Data")
st.download_button("⬇️ Download cleaned Excel", data=excel_buffer.getvalue(), file_name="cleaned_dataset.xlsx",
                   mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

st.success("Prototype workflow completed. Always review flagged invalid values before using the cleaned dataset.")
st.caption("Prototype limitation: duplicate detection checks fully identical rows; city standardization is a simple title-case rule; email and age checks flag issues for human review.")
